AlignViewToFace script by Carl-Mikael Lagnecrantz written 2005-08-08
Align the current perspective view to the face under the mouse. Especially useful
when a toolmode is active, like the cut tool, since viewport navigation in those cases is
restricted.

Usage: Run the script, you will then have a category named "CMLCreative" in the 
customize menu. Assign the AlignViewToFace macroscript to a hotkey.