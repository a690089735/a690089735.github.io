![emmmmmmm](Image.gif)
# SpringBone
弹簧骨骼效果。
基于Unity2017.1。未在其他版本测试。
相关文章：http://www.cnblogs.com/yangrouchuan/p/7650115.html

# Engligh ver
Spring bone effect for Unity. Tested on Unity2017.1.

# Features
* One single script and all works!
* works with or without animator ( or anything changes rotation).
* physics based forces configuration.

Unity-chan asset from https://assetstore.unity.com/packages/3d/characters/unity-chan-model-18705